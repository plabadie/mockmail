#!/bin/sh
java -jar mockmail.jar